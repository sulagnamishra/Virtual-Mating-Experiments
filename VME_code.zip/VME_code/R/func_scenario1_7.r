#Scenario 1-7 (Runs all the scenarios at variable frequencies)
scenario1_7<-function(parmsinit)
{  
out <- NULL
parmsinit_back<-c(parmsinit[names(parmsinit) != "logGamma"])
for (freq in c(0.25,0.5,1,2,3,4,6,8)) {  #sampling frequencies at the which the logGamma is estimated
  for (scenario_num in 1:7) {
    print(scenario_num)
    fit <- optimize(f=ssr, interval=c(-16,-8),     #parameter estimation for 1 parameter (logGamma)
                    scenario_num=scenario_num, freq = freq,parmsinit=parmsinit_back,obs=obs)
    print(fit$minimum)
    
    out <- rbind(out, cbind(scenario_num=scenario_num, samplingfreq=freq,
                            logGamma=fit$minimum))
    if (plotCurves) {
      ssr(logGamma=fit$minimum, scenario_num=scenario_num,
          freq=freq, parmsinit=parmsinit_back,obs=obs,
          pdf=paste0(odir,"scenario",scenario_num,"freq",freq,".pdf"))
    }
  }
}
write.table(out, file=paste0(odir,"out_scenario_freq.txt"), sep="\t", quote=FALSE,
            row.names=FALSE, col.names=TRUE)

#lineplot
out_scenario<-out
out_scenario[,"logGamma"]<-out_scenario[,"logGamma"]- parmsinit[["logGamma"]]
choosefrom<-c(11,12,13,15,16,17,6)
out_scenario_process<-reshape(as.data.frame(out_scenario),idvar="samplingfreq",timevar="scenario_num", direction="wide")
#par(mar=c(5,4,4,8),xpd=TRUE) #top legend
par(mar=c(8,6,1,4),xpd=TRUE) #bottom legend
plot(out_scenario_process[,"samplingfreq"],out_scenario_process[,"logGamma.1"],xlab="Sampling frequency in hours", 
     ylab=expression(paste("Error in predicted ",gamma," in log10 units")),pch=choosefrom[1],cex=1.5,type="b",
     ylim=range(out_scenario[,"logGamma"]))
for(i in 3:ncol(out_scenario_process)){
  lines(out_scenario_process[,"samplingfreq"],out_scenario_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
}
names_legends=c("1. none", expression(italic("2. CST")),expression(italic("3. CST+LAG")),expression(italic("4. CST+SAT")),expression(italic("5. CST+LAG+SAT")),expression(italic("6. CST+SAT+MAT")),"7. all")
textwidth<-c(0,0.2,0.5,0.5,0.5,0.5,0.5)
legend("bottom",inset = c(-0.45),legend=names_legends,
       title=expression(paste(bold("Functions included in the backward model: "))),pch = choosefrom, ncol=4, bty="n", title.adj = 0) 

#Heatmap plot style
if(FALSE){
out <- acast(samplingfreq ~ scenario_num, data=as.data.frame(out), value.var="logGamma")
out <- out - -12
par(mar=c(5,4,4,4))
filled.contour(x=as.numeric(rownames(out)), y=as.numeric(colnames(out)), z=out,
               xlab="Sampling freq in hours", ylab="Scenario (model complexity)",
               zlim=max(abs(out))*c(-1,1),
               color.palette=colorRampPalette(c("green","blue","white","darkorange","red")))
title(main="Error in predicted logGamma")
}

out

}