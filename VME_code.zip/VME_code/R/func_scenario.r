#returns the row numbers of the processes based on the scenarios
scenario<-function(num)
{
  if(num<=5){
  no_process<-4
  subset<-seq(num*no_process-(no_process-1),num*no_process) #because they are multiples of (no of the processes))
  } else {                                                  #when mat is introduced, the number of statevariables and processes also change
    last<-5*4
    no_process<-5
    subset<-seq(last+(num-5)*no_process-(no_process-1),last+(num-5)*no_process)
  }
  return(subset)
}