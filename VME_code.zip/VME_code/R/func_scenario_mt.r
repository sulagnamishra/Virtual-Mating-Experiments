scenario_mt<-function(parmsinit)
{
  #case - variable maturation time
  #maturation time function shows significant variablity when run for logGamma >= -9.5 in the default settings
  testfreq<-2
  out_mt<-NULL
  for (mt in c(0.001,0.25,0.5,1,2)){
    parmsinit_new<-c(parmsinit[names(parmsinit) != "mt"], mt=mt)
    parmsinit_back<-c(parmsinit_new[names(parmsinit_new) != "logGamma"])
    obs<-forwardmodel(scenario_num=7, parmsinit = parmsinit_new)
    for (scenario_num in 1:7) {
      fit_mt <- optimize(f=ssr, interval=c(-20,-6),
                         scenario_num=scenario_num, freq = testfreq,parmsinit=parmsinit_back,obs=obs)
      out_mt <- rbind(out_mt, cbind(scenario_num=scenario_num, mt=mt,freq=testfreq,
                                    logGamma=fit_mt$minimum))
      if (plotCurves_mt) {
        ssr(logGamma=fit_mt$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,
            pdf=paste0(odir,"scenario",scenario_num,"mt",mt,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_mt, file=paste0(odir,"out_mt_scenario.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  #
  #linear plots
  out_mt_process<-out_mt
  out_mt_process[,"logGamma"]<-out_mt_process[,"logGamma"]- parmsinit[["logGamma"]]
  choosefrom<-c(11,12,13,15,16,17,6)
  par(mar=c(8,6,1,4),xpd=TRUE) #bottom legend
  out_mt_process<-reshape(subset(as.data.frame(out_mt_process),select= -freq),idvar="mt",timevar="scenario_num", direction="wide")
  plot(out_mt_process[,"mt"],out_mt_process[,"logGamma.1"],xlab="Maturation time for T in hours", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=range(out_mt[,"logGamma"]-parmsinit[["logGamma"]]))
  for(i in 3:ncol(out_mt_process)){
    lines(out_mt_process[,"mt"],out_mt_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  names_legends=c("1. none", expression(italic("2. CST")),expression(italic("3. CST+LAG")),expression(italic("4. CST+SAT")),expression(italic("5. CST+LAG+SAT")),expression(italic("6. CST+SAT+MAT")),"7. all")
  textwidth<-c(0,0.2,0.5,0.5,0.5,0.5,0.5)

  legend("bottom",inset = c(-0.45),legend=names_legends,
         title=expression(paste(bold("Functions included in the backward model: "))),pch = choosefrom, ncol=4, bty="n", title.adj = 0) 
  
  #
  #heatmap plots
  if(FALSE){
  out_mt <- acast(mt ~ scenario_num, data=as.data.frame(out_mt), value.var="logGamma")
  out_mt <- out_mt - parmsinit[["logGamma"]]
  par(mfcol=c(1,1))
  filled.contour(x=as.numeric(rownames(out_mt)), y=as.numeric(colnames(out_mt)), z=out_mt,
                 xlab="Maturation time (hour)", ylab="Scenario (model complexity)",
                 zlim=max(abs(out_mt))*c(-1,1),
                 color.palette=colorRampPalette(c("green","blue","white","darkorange","red")))
  title(main="Error in predicted logGamma (mt ~ scenario)")
  }
  out_mt
}