scenario_cost<-function()
{
  testfreq<-2
  out_cost<-NULL
  for (cost in c(0,0.1,0.2,0.5,0.7)) {
    parmsinit_new<-c(parmsinit[names(parmsinit) != "cost"], cost=cost)
    parmsinit_back<-c(parmsinit_new[names(parmsinit_new) != "logGamma"])
    obs<-forwardmodel(scenario_num=7, parmsinit = parmsinit_new)
    for (scenario_num in 1:7) {
      fit_cost <- optimize(f=ssr, interval=c(-20,-8),
                         scenario_num=scenario_num, freq = testfreq,parmsinit=parmsinit_back,obs=obs)
      out_cost <- rbind(out_cost, cbind(scenario_num=scenario_num, cost=cost,freq=testfreq,
                                    logGamma=fit_cost$minimum))
      if (plotCurves_cost) {
        ssr(logGamma=fit_cost$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,
            pdf=paste0(odir,"scenario",scenario_num,"cost",cost,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_cost, file=paste0(odir,"out_cost_scenario.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  #
  #plot linear plot
  out_cost_process<-out_cost
  out_cost_process[,"logGamma"]<-out_cost_process[,"logGamma"]- parmsinit[["logGamma"]]
  choosefrom<-c(11,12,13,15,16,17,6)
  par(mar=c(8,6,1,4),xpd=TRUE) #bottom legend
  out_cost_process<-reshape(subset(as.data.frame(out_cost_process),select= -freq),
                            idvar="cost",timevar="scenario_num", direction="wide")
  plot(out_cost_process[,"cost"],out_cost_process[,"logGamma.1"],xlab="Cost", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=range(out_cost[,"logGamma"]-parmsinit[["logGamma"]]))
  for(i in 3:ncol(out_cost_process)){
    lines(out_cost_process[,"cost"],out_cost_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  names_legends=c("1. none", expression(italic("2. CST")),expression(italic("3. CST+LAG")),expression(italic("4. CST+SAT")),expression(italic("5. CST+LAG+SAT")),expression(italic("6. CST+SAT+MAT")),"7. all")
  textwidth<-c(0,0.2,0.5,0.5,0.5,0.5,0.5)
  legend("bottom",inset = c(-0.45),legend=names_legends,
         title=expression(paste(bold("Functions included in BM: "))),
         pch = choosefrom, ncol=4, bty="n", title.adj = 0) 
  #
  #plot heat map
  if(FALSE){
  out_cost <- acast(cost ~ scenario_num, data=as.data.frame(out_cost), value.var="logGamma")
  out_cost <- out_cost - -12
  par(mfcol=c(1,1))
  filled.contour(x=as.numeric(rownames(out_cost)), y=as.numeric(colnames(out_cost)), z=out_cost,
                 xlab="Plasmid cost", ylab="Scenario (model complexity)",
                 zlim=max(abs(out_cost))*c(-1,1),
                 color.palette=colorRampPalette(c("green","blue","white","darkorange","red")))
  title(main="Error in predicted logGamma (cost ~ scenario)")
  }
  out_cost
}