#backward model to estimate logGamma.
backwardmodel<-function(scenario_num,logGamma,parmsinit,times)
{
  pros_sub<-scenario(scenario_num)
  if(scenario_num<=5){
    fm <- rodeo$new(vars=rd("vars.txt"), pars=rd("pars.txt"),
                    funs=rd("funs.txt"), pros=rd("pros_mat_all.txt")[pros_sub,],
                    stoi=as.matrix(rd("stoi.txt", row.names=1)), asMatrix=TRUE, dim=c(1))
  }else{
    fm <- rodeo$new(vars=rd("vars_mat.txt"), pars=rd("pars.txt"),
                    funs=rd("funs.txt"), pros=rd("pros_mat_all.txt")[pros_sub,],
                    stoi=as.matrix(rd("stoi_mat.txt", row.names=1)), asMatrix=TRUE, dim=c(1))}
  
  fm$compile(sources=paste0(dir,"/functions.f95"))
  #initalize state variables
  tmp <- c(D=1e2, R=1e6, T=0, T_mature=0)[fm$namesVars()] 
  fm$setVars(tmp)
  
  #initialize parameters
    tmp<-c(parmsinit, logGamma=logGamma)[fm$namesPars()]
    fm$setPars(tmp)
    
  #---------------------------------------------------------------------------------------------------
  #Normal dynamic solution
      out<-fm$dynamics(times=times)
  return(out)
}