scenario_lp<-function()
{
  #case - variable lagphase length
  testfreq<-2
  out_lp<-NULL
  i<-0
  for (lp in c(0,.2,.5,1,1.5,2)) {
    i<-i+1
    parmsinit_lp<-c(parmsinit[names(parmsinit) != "lp"], lp=lp)
    parmsinit_back<-c(parmsinit_lp[names(parmsinit_lp) != "logGamma"])
    obs<-forwardmodel(scenario_num=7, parmsinit = parmsinit_lp)
    for (scenario_num in 1:7) {
      fit_lp <- optimize(f=ssr, interval=c(-16,-8),
                         scenario_num=scenario_num, freq = testfreq,parmsinit=parmsinit_back,obs=obs)
      out_lp <- rbind(out_lp, cbind(scenario_num=scenario_num, lp=lp,freq=testfreq,
                                    logGamma=fit_lp$minimum))
      if (plotCurves_lp) {
        ssr(logGamma=fit_lp$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,
            pdf=paste0(odir,"scenario",scenario_num,"lp",lp,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_lp, file=paste0(odir,"out_lp_scenario.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  #
  #linear plots
  out_lp_process<-out_lp
  out_lp_process[,"logGamma"]<-out_lp_process[,"logGamma"]- parmsinit[["logGamma"]]
  choosefrom<-c(11,12,13,15,16,17,6)
  par(mar=c(8,6,1,4),xpd=TRUE) #bottom legend
  out_lp_process<-reshape(subset(as.data.frame(out_lp_process),select= -freq),idvar="lp",timevar="scenario_num", direction="wide")
  plot(out_lp_process[,"lp"],out_lp_process[,"logGamma.1"],xlab="Lag Phase in hours", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=range(out_lp[,"logGamma"]-parmsinit[["logGamma"]]))
  for(i in 3:ncol(out_lp_process)){
    lines(out_lp_process[,"lp"],out_lp_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  names_legends=c("1. none", expression(italic("2. CST")),expression(italic("3. CST+LAG")),expression(italic("4. CST+SAT")),expression(italic("5. CST+LAG+SAT")),expression(italic("6. CST+SAT+MAT")),"7. all")
  textwidth<-c(0,0.2,0.5,0.5,0.5,0.5,0.5)
  legend("bottom",inset = c(-0.45),legend=names_legends,
         title=expression(paste(bold("Functions included in BM: "))),pch = choosefrom, ncol=4, bty="n", title.adj = 0) 
  #
  #heatmap plots
  if(FALSE){
  out_lp <- acast(lp ~ scenario_num, data=as.data.frame(out_lp), value.var="logGamma")
  out_lp <- out_lp - -12
  par(mfcol=c(1,1))
  filled.contour(x=as.numeric(rownames(out_lp)), y=as.numeric(colnames(out_lp)), z=out_lp,
                 xlab="Log Phase(hour)", ylab="Scenario (model complexity)",
                 zlim=max(abs(out_lp))*c(-1,1),
                 color.palette=colorRampPalette(c("green","blue","white","darkorange","red")))
  title(main="Error in predicted logGamma (Logphase ~ scenario)")
  }
  out_lp
}