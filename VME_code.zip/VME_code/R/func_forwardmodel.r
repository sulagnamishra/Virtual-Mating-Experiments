#forward model with cost, lag phase, phase effect and maturation time to generate data.
#case defination - cost + lagphase + phase effect + mt -> Scenario7
forwardmodel<-function(scenario_num,freq=NULL,lg=NULL,parmsinit)
{
pros_sub<-scenario(scenario_num)

if(scenario_num<=5){
  fm <- rodeo$new(vars=rd("vars.txt"), pars=rd("pars.txt"),
                  funs=rd("funs.txt"), pros=rd("pros_mat_all.txt")[pros_sub,],
                  stoi=as.matrix(rd("stoi.txt", row.names=1)), asMatrix=TRUE, dim=c(1))
  }else{
fm <- rodeo$new(vars=rd("vars_mat.txt"), pars=rd("pars.txt"),
                funs=rd("funs.txt"), pros=rd("pros_mat_all.txt")[pros_sub,],
                stoi=as.matrix(rd("stoi_mat.txt", row.names=1)), asMatrix=TRUE, dim=c(1))}

fm$compile(sources=paste0(dir,"/functions.f95"))

#initalize state variables
tmp <- c(D=1e2, R=1e6, T=0, T_mature=0)[fm$namesVars()] 
fm$setVars(tmp)
#initialize parameters
if(is.null(lg)){
tmp <- parmsinit[fm$namesPars()] 
fm$setPars(tmp)
}else{
  tmp<-c(parmsinit[names(parmsinit) != "logGamma"], logGamma=lg)[fm$namesPars()]
  fm$setPars(tmp)
  }
if(is.null(freq))
{
times=seq(from = 0, to = 12, by = 0.25)
}else 
{
times=seq(from = 0, to = 12, by = freq)
}
#---------------------------------------------------------------------------------------------------
#Normal dynamic solution
out<-fm$dynamics(times=times)
#plot(out)

##....stores the data only for the full forward model
#if(is.null(freq))  
#{
#write.table(out, file=paste0(odir,"data.txt"), sep="\t", quote=FALSE,
#            row.names=FALSE, col.names=TRUE)
#}    
return(out)
}