scenario_mu<-function()
{
  testfreq<-2
  out_mu<-NULL
  i<-0
  for (mu in c(.5,1,1.5,2,2.5)) {   #Variable mu (growth rate constant)
    i<-i+1
    parmsinit_mu<-c(parmsinit[names(parmsinit) != "mu"], mu=mu)
    parmsinit_back<-c(parmsinit_mu[names(parmsinit_mu) != "logGamma"])
    obs<-forwardmodel(scenario_num=7, parmsinit = parmsinit_mu)
    for (scenario_num in 1:7) {
      fit_mu <- optimize(f=ssr, interval=c(-16,-8),
                         scenario_num=scenario_num, freq = testfreq,parmsinit=parmsinit_back,obs=obs)
      out_mu <- rbind(out_mu, cbind(scenario_num=scenario_num, mu=mu,freq=testfreq,
                                    logGamma=fit_mu$minimum))
      if (plotCurves_mu) {
        ssr(logGamma=fit_mu$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,
            pdf=paste0(odir,"scenario",scenario_num,"mu",mu,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_mu, file=paste0(odir,"out_mu_scenario.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  #
  #linear plot
  out_mu_process<-out_mu
  out_mu_process[,"logGamma"]<-out_mu_process[,"logGamma"]- parmsinit[["logGamma"]]
  choosefrom<-c(11,12,13,15,16,17,6)
  par(mar=c(8,6,1,4),xpd=TRUE) #bottom legend
  out_mu_process<-reshape(subset(as.data.frame(out_mu_process),select= -freq),idvar="mu",timevar="scenario_num", direction="wide")
  plot(out_mu_process[,"mu"],out_mu_process[,"logGamma.1"],xlab=expression(paste(mu, " in hour"^"-1")), 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=range(out_mu[,"logGamma"]-parmsinit[["logGamma"]]))
  
  for(i in 3:ncol(out_mu_process)){
    lines(out_mu_process[,"mu"],out_mu_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  names_legends=c("1. none", expression(italic("2. CST")),expression(italic("3. CST+LAG")),expression(italic("4. CST+SAT")),expression(italic("5. CST+LAG+SAT")),expression(italic("6. CST+SAT+MAT")),"7. all")
  textwidth<-c(0,0.2,0.5,0.5,0.5,0.5,0.5)
  legend("bottom",inset = c(-0.45),legend=names_legends,
         title=expression(paste(bold("Functions included in BM: "))),pch = choosefrom, ncol=4, bty="n", title.adj = 0) 
  #
  #heat map plot
  if(FALSE)
  {
    out_mu <- acast(mu ~ scenario_num, data=as.data.frame(out_mu), value.var="logGamma")
  out_mu <- out_mu - -12
  par(mfcol=c(1,1))
  filled.contour(x=as.numeric(rownames(out_mu)), y=as.numeric(colnames(out_mu)), z=out_mu,
                 xlab="Mu_R(1/hour)", ylab="Scenario (model complexity)",
                 zlim=max(abs(out_mu))*c(-1,1),
                 color.palette=colorRampPalette(c("green","blue","white","darkorange","red")))
  title(main="Error in predicted logGamma (mu ~ scenario)")
}
  out_mu
}