# objective function used to estimate parameter gamma
ssr <- function(logGamma,scenario_num,freq,parmsinit,obs,pdf=NULL,forwardsampling=NULL,backwardsampling=NULL) {
  y<-c("time","D","R","T")
  obs_subset<-obs[which(obs[,"time"]%%freq==0),y]
  times=seq(from = 0, to = 12, by = freq)
  if(!is.null(forwardsampling))
  {
    ratio<-round(forwardsampling/backwardsampling,2)
    rownumbers<-seq(1,nrow(obs),by=ratio)
    obs_subset<-obs[rownumbers,] 
    times<-obs_subset[,"time"]
    }
  sim<-backwardmodel(scenario_num = scenario_num, 
                     logGamma=logGamma,parmsinit=parmsinit,times)[,y] #logGamma to be predicted
  #print(sim)

  #---------------------------------------------------------------------------------------------------
 #plot curves for D,R,T observed vs simulated densities
   if(!is.null(pdf))
  {
    pdf(file=pdf, width=8, height=8)
    omar <- par("mar")
    y<-c("D","R","T")
    yrange= c(1e2, max(rbind(obs_subset,sim)[,y]))
    plot(range(times), yrange, type="n", ann=FALSE,
         log="y",xlab="Density of the strains in CFU/ml",ylab="Time in hours")
    clr <- c(D="red", R="blue", T="magenta")
    for (v in names(clr)) {
      points(obs_subset[,c("time",v)], pch=20, col=clr[v])
      lines(sim[,c("time",v)], pch=20, col=clr[v])
    }
    title(main=paste0("Scenario:",scenario_num))
    legend("bottomright", bty="n", legend=substitute(
      paste("log",{}[10],gamma,"=",lg), list(lg=signif(logGamma,3))))
    par(mar=omar)
    graphics.off()
  }
  i <- 2:nrow(sim)
  out <- sum((log10(obs_subset[i,c("D","R","T")]) - log10(sim[i,c("D","R","T")]))^2)
  if (!is.finite(out)) {
    print("obs")
    print(obs_subset[i,c("D","R","T")])
    print("sim")
    print(sim[i,c("D","R","T")])
    stop("non-finite sum of squared residuals") 
  }
  out
}