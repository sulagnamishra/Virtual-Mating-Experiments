rm(list=ls())
setwd('/path/to/the/working/Directory/VME_code/R')  #please add the path to the working Directory here
odir <- "../out/"
dir<-"../Rodeo"

#plotcurves_(case) plots the densities of the 3 strains (Observed Vs simulated) over time.
plotCurves<-TRUE
plotCurves_mu<-FALSE
plotCurves_lg<-FALSE
plotCurves_lp<-FALSE
plotCurves_mt<-FALSE
plotCurves_cost<-FALSE

# packages
library("deSolve")
library("rodeo")
library("lhs")
library("plyr")
library("reshape2")
library("FME")

# load utility functions
sources <- list.files(path=".", pattern="^func_.+[.]r$", full.names=TRUE)
for (src in sources) {
  source(src)
  print(paste0("loaded '",src,"'"))
}
rd <- function(f, ...) {
  read.table(paste0(dir,"/",f), header=TRUE, sep="\t", ...)
}
#Basic forward model and data generator
#Default parameters
parmsinit<-c(mu=1.7,cost=0.3,kc=1e10,logGamma=-12,lp = 1.5,mt=1)

#Forward model
obs<-forwardmodel(scenario_num=7,parmsinit=parmsinit)

#Results - The functions below use the virtual data generated from the forward model 
# and estimate logGamma using the backward models

#The  following functions returns the results logGamma for secenario vs variable parameter in form of a matrix
#and plots the result. The outputs are stored in .txt format in the out folder.

#Scenario 1-7 (All scenarios tested at different sampling frequencies)
out_scenario<-scenario1_7(parmsinit=parmsinit)

#Local sensitivity analysis
#case 1- Variable mu 
out_mu<-scenario_mu()

#case 2- Variable logGamma
out_lg<-scenario_lg()

#case 3 - Changed lagPhase length
out_lp<-scenario_lp()

#case 4: changed mt (maturation time for T)
out_mt<-scenario_mt(parmsinit=parmsinit)

#case 5: changed plasmid bearing cost
out_cost<-scenario_cost()


