scenario_D2R<-function(parmsinit,D2R,leg)
{
  #Sensitivity wrt D:R ratio
  testfreq<-2
  out_D2R<-NULL
  D2Rcases<-matrix(c(1000,1,100,1,10,1,1,1,1,10,1,100,1,1000),ncol=2,byrow=TRUE)
  D2Rcases<-cbind(D2Rcases*D2R[1:2],D2R[3],D2R[4],D2R[5])
  colnames(D2Rcases)<-c("D","R","T","T_young","T_mature")
  
  for (i in 1:nrow(D2Rcases)){
    D2R<-D2Rcases[i,]
    parmsinit_back<-c(parmsinit[names(parmsinit) != "logGamma"])
    obs<-forwardmodel(scenario_num=10, parmsinit = parmsinit,D2R=D2R)
    for (scenario_num in 1:10) {
      fit_D2R <- optimize(f=ssr, interval=c(-20,-8),
                         scenario_num=scenario_num, freq = testfreq,
                         parmsinit=parmsinit_back,obs=obs,D2R=D2R)
        out_D2R <- rbind(out_D2R, cbind(scenario_num=scenario_num, D2R=i,freq=testfreq,
                                    logGamma=fit_D2R$minimum))
      if (plotCurves_D2R) {
        ssr(logGamma=fit_D2R$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,D2R=D2R,
            pdf=paste0(odir,"scenario",scenario_num,"D2R",i,"freq",testfreq,".pdf"))
      }
    }
  }
  #...........Writing to the disk...............................
  write.table(out_D2R, file=paste0(odir,"out_D2R.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  out_D2R #(return value)
  
  ##..........Sensitivity Plots..................................
  pdf(file=paste0(odir,"D2R_pure_1",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(1,2,3,4,8)
  choosefrom<-c(6,12,13,15,1)
  out_D2R_process<-out_D2R[which(out_D2R$scenario_num%in%scenarionums),]
  out_D2R_process["logGamma"]<-out_D2R_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_D2R_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_D2R_process<-reshape(subset(as.data.frame(out_D2R_process),select= -freq),idvar="D2R",timevar="scenario_num", direction="wide")
  plot(out_D2R_process[,"D2R"],out_D2R_process[,"logGamma.1"],xlab="Donor to Recepient ratio", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim,xaxt='n')
  axis(1,at=seq(1,nrow(D2Rcases),by=1),labels=c("1000:1","100:1","10:1","1:1","1:10","1:100","1:1000"))
  for(i in 3:ncol(out_D2R_process)){
    lines(out_D2R_process[,"D2R"],out_D2R_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  
  if(leg==TRUE){
    names_legends=c("1. None", expression(italic("2. CST")),expression(italic("3. LAG")),expression(italic("4. DNS")),expression(italic("5. MAT")))
    legend("bottom",inset = c(-0.45),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, bty="n", title.adj = 0, horiz=T)}
graphics.off()
  
  
  #Plot for combination scenarios
  pdf(file=paste0(odir,"scenarioD2R_combination",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(5,6,7,9,10)   #Scenario nums based on the sequence in the code.
  choosefrom<-c(11,17,16,8,0)
  out_D2R_process<-out_D2R[which(out_D2R$scenario_num%in%scenarionums),]
  out_D2R_process[,"logGamma"]<-out_D2R_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_D2R_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_D2R_process<-reshape(subset(as.data.frame(out_D2R_process),select= -freq),
                           idvar="D2R",timevar="scenario_num", direction="wide")
  plot(out_D2R_process[,"D2R"],out_D2R_process[,"logGamma.5"],xlab="Donor to Recepient ratio", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),xaxt='n',
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  axis(1,at=seq(1,nrow(D2Rcases),by=1),labels=c("1000:1","100:1","10:1","1:1","1:10","1:100","1:1000"))
  for(i in 3:ncol(out_D2R_process)){
    lines(out_D2R_process[,"D2R"],out_D2R_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
  names_legends=c(expression(italic("6. CST+LAG")),expression(italic("7. CST+DNS")),
                  expression(italic("8. CST+LAG+DNS")),expression(italic("9. CST+DNS+MAT")),"10. All")
  legend("bottom",inset = c(-0.55),legend=names_legends,
         title=expression(paste(bold("Functions included in the backward model: "))),
         pch = choosefrom, ncol = 2, bty="n", title.adj = 0)}
  graphics.off()
}
