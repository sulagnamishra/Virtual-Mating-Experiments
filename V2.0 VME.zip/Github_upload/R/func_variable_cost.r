scenario_cost<-function(D2R,leg)
{
  #case 2- Changed cost
  testfreq<-2
  out_cost<-NULL
  for (cost in c(0,0.1,0.2,0.5,0.7)) {
    parmsinit_new<-c(parmsinit[names(parmsinit) != "cost"], cost=cost)
    parmsinit_back<-c(parmsinit_new[names(parmsinit_new) != "logGamma"])
    obs<-forwardmodel(scenario_num=10, parmsinit = parmsinit_new,D2R=D2R)
    for (scenario_num in 1:10) {
      fit_cost <- optimize(f=ssr, interval=c(-20,-8),
                         scenario_num=scenario_num, freq = testfreq,parmsinit=parmsinit_back,obs=obs,
                         D2R=D2R)
      out_cost <- rbind(out_cost, cbind(scenario_num=scenario_num, cost=cost,freq=testfreq,
                                    logGamma=fit_cost$minimum))
      if (plotCurves_cost) {
        ssr(logGamma=fit_cost$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,D2R=D2R,
            pdf=paste0(odir,"scenario",scenario_num,"cost",cost,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_cost, file=paste0(odir,"out_cost_scenario_full.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  out_cost
  #
  pdf(file=paste0(odir,"cost_full_pure",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(1,2,3,4,8)
  choosefrom<-c(6,12,13,15,1)
  out_cost_process<-out_cost[which(out_cost$scenario_num%in%scenarionums),]
  out_cost_process[,"logGamma"]<-out_cost_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_cost_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_cost_process<-reshape(subset(as.data.frame(out_cost_process),select= -freq),
                            idvar="cost",timevar="scenario_num", direction="wide")
  plot(out_cost_process[,"cost"],out_cost_process[,"logGamma.1"],xlab="Cost", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  for(i in 3:ncol(out_cost_process)){
    lines(out_cost_process[,"cost"],out_cost_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c("1. None", expression(italic("2. CST")),expression(italic("3. LAG")),expression(italic("4. DNS")),expression(italic("5. MAT")))
    legend("bottom",inset = c(-0.45),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, bty="n", title.adj = 0, horiz=T)} 
  graphics.off()
  
  #.....................Combination scenarios
  pdf(file=paste0(odir,"cost_full_combination",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(5,6,7,9,10)   #Scenario nums based on the sequence in the code.
  choosefrom<-c(11,17,16,8,0)
  out_cost_process<-out_cost[which(out_cost$scenario_num%in%scenarionums),]
  out_cost_process[,"logGamma"]<-out_cost_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_cost_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_cost_process<-reshape(subset(as.data.frame(out_cost_process),select= -freq),
                            idvar="cost",timevar="scenario_num", direction="wide")
  plot(out_cost_process[,"cost"],out_cost_process[,"logGamma.5"],xlab="Cost", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  for(i in 3:ncol(out_cost_process)){
    lines(out_cost_process[,"cost"],out_cost_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c(expression(italic("6. CST+LAG")),expression(italic("7. CST+DNS")),
                    expression(italic("8. CST+LAG+DNS")),expression(italic("9. CST+DNS+MAT")),"10. All")
    legend("bottom",inset = c(-0.55),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, ncol = 2, bty="n", title.adj = 0) 
  } 
  graphics.off()

}