scenario_mt<-function(parmsinit,D2R,leg)
{
  #case 2- Changed maturation time
  testfreq<-2
  out_mt<-NULL
  for (mt in c(0.001,0.25,0.5,1,2)){
    parmsinit_new<-c(parmsinit[names(parmsinit) != "mt"], mt=mt)
    parmsinit_back<-c(parmsinit_new[names(parmsinit_new) != "logGamma"])
    obs<-forwardmodel(scenario_num=10, parmsinit = parmsinit_new,D2R=D2R)
    for (scenario_num in 1:10) {
      fit_mt <- optimize(f=ssr, interval=c(-20,-6),
                         scenario_num=scenario_num, freq = testfreq,
                         parmsinit=parmsinit_back,obs=obs,D2R=D2R)
      out_mt <- rbind(out_mt, cbind(scenario_num=scenario_num, mt=mt,freq=testfreq,
                                    logGamma=fit_mt$minimum))
      if (plotCurves_mt) {
        ssr(logGamma=fit_mt$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,D2R=D2R,
            pdf=paste0(odir,"scenario",scenario_num,"mt",mt,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_mt, file=paste0(odir,"out_mt_scenario_x.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  out_mt #(return)
  #
  pdf(file=paste0(odir,"mt_pure",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(1,2,3,4,8)
  choosefrom<-c(6,12,13,15,1)
  out_mt_process<-out_mt[which(out_mt$scenario_num%in%scenarionums),]
  out_mt_process[,"logGamma"]<-out_mt_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_mt_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_mt_process<-reshape(subset(as.data.frame(out_mt_process),select= -freq),idvar="mt",timevar="scenario_num", direction="wide")
  plot(out_mt_process[,"mt"],out_mt_process[,"logGamma.1"],xlab="Maturation time for T in hours", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  for(i in 3:ncol(out_mt_process)){
    lines(out_mt_process[,"mt"],out_mt_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c("1. None", expression(italic("2. CST")),expression(italic("3. LAG")),expression(italic("4. DNS")),expression(italic("5. MAT")))
    legend("bottom",inset = c(-0.45),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, bty="n", title.adj = 0, horiz=T)} 
  graphics.off()
  #.....Combination scenarios......
  pdf(file=paste0(odir,"mt_combination",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(5,6,7,9,10)   #Scenario nums based on the sequence in the code.
  choosefrom<-c(11,17,16,8,0)
  out_mt_process<-out_mt[which(out_mt$scenario_num%in%scenarionums),]
  out_mt_process[,"logGamma"]<-out_mt_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_mt_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_mt_process<-reshape(subset(as.data.frame(out_mt_process),select= -freq),idvar="mt",timevar="scenario_num", direction="wide")
  plot(out_mt_process[,"mt"],out_mt_process[,"logGamma.5"],xlab="Maturation time for T in hours", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  for(i in 3:ncol(out_mt_process)){
    lines(out_mt_process[,"mt"],out_mt_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c(expression(italic("6. CST+LAG")),expression(italic("7. CST+DNS")),
                    expression(italic("8. CST+LAG+DNS")),expression(italic("9. CST+DNS+MAT")),"10. All")
    legend("bottom",inset = c(-0.55),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, ncol = 2, bty="n", title.adj = 0)}
  graphics.off()
}