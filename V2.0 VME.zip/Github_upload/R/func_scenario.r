#returns the row numbers of the processes based on the scenarios
scenario<-function(num)
{
  if(num<=7){
  no_process<-4
  subset<-seq(num*no_process-(no_process-1),num*no_process) #because they are multiples of (no of the processes))
  } else {
    last<-7*4
    no_process<-6
    subset<-seq(last+(num-7)*no_process-(no_process-1),last+(num-7)*no_process)
  }
  return(subset)
}