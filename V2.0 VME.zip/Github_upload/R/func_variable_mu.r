scenario_mu<-function(D2R,legend)
{
  testfreq<-2
  out_mu<-NULL
  i<-0
  #phaseEffect<-c(12,10,9,7,5)
  #mp_pe<-c(95,92,88,70,50)
  for (mu in c(.5,1,1.5,2,2.5)) {
    i<-i+1
    parmsinit_mu<-c(parmsinit[names(parmsinit) != "mu"], mu=mu)
    #parmsinit_mp_pe<-c(parmsinit_mu[names(parmsinit_mu) != "mp_pe"], mp_pe=mp_pe[i])
    #parmsinit_new<-c(parmsinit_mp_pe[names(parmsinit_mp_pe) != "pe"], pe=phaseEffect[i])
    parmsinit_back<-c(parmsinit_mu[names(parmsinit_mu) != "logGamma"])
    obs<-forwardmodel(scenario_num=10, parmsinit = parmsinit_mu,D2R=D2R)
    for (scenario_num in 1:10) {
      fit_mu <- optimize(f=ssr, interval=c(-16,-8),
                         scenario_num=scenario_num, freq = testfreq,parmsinit=parmsinit_back,obs=obs,D2R=D2R)
      out_mu <- rbind(out_mu, cbind(scenario_num=scenario_num, mu=mu,freq=testfreq,
                                    logGamma=fit_mu$minimum))
      if (plotCurves_mu) {
        ssr(logGamma=fit_mu$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,D2R=D2R,
            pdf=paste0(odir,"scenario",scenario_num,"mu",mu,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_mu, file=paste0(odir,"out_mu_scenario.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  out_mu #return
  #
  pdf(file=paste0(odir,"mu_pure",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(1,2,3,4,8)
  choosefrom<-c(6,12,13,15,1)
  out_mu_process<-out_mu[which(out_mu$scenario_num%in%scenarionums),]
  out_mu_process[,"logGamma"]<-out_mu_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_mu_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_mu_process<-reshape(subset(as.data.frame(out_mu_process),select= -freq),idvar="mu",timevar="scenario_num", direction="wide")
  plot(out_mu_process[,"mu"],out_mu_process[,"logGamma.1"],xlab=expression(paste(mu, " in hour"^"-1")), 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  
  for(i in 3:ncol(out_mu_process)){
    lines(out_mu_process[,"mu"],out_mu_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c("1. None", expression(italic("2. CST")),expression(italic("3. LAG")),expression(italic("4. DNS")),expression(italic("5. MAT")))
    legend("bottom",inset = c(-0.45),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, bty="n", title.adj = 0, horiz=T)}
  
  graphics.off()
  
  #
  pdf(file=paste0(odir,"mu_combination",".pdf"), width=7.5, height=5.5)
  omar <- par("mar")
  scenarionums<-c(5,6,7,9,10)   #Scenario nums based on the sequence in the code.
  choosefrom<-c(11,17,16,8,0)
  out_mu_process<-out_mu[which(out_mu$scenario_num%in%scenarionums),]
  out_mu_process[,"logGamma"]<-out_mu_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_mu_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_mu_process<-reshape(subset(as.data.frame(out_mu_process),select= -freq),idvar="mu",timevar="scenario_num", direction="wide")
  plot(out_mu_process[,"mu"],out_mu_process[,"logGamma.5"],xlab=expression(paste(mu, " in hour"^"-1")), 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  
  for(i in 3:ncol(out_mu_process)){
    lines(out_mu_process[,"mu"],out_mu_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c(expression(italic("6. CST+LAG")),expression(italic("7. CST+DNS")),
                    expression(italic("8. CST+LAG+DNS")),expression(italic("9. CST+DNS+MAT")),"10. All")
    legend("bottom",inset = c(-0.55),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, ncol = 2, bty="n", title.adj = 0)}
  graphics.off()
}