#Scenario 1-10
scenario1_10<-function(parmsinit,D2R,obs,leg)
{  
out <- NULL
#fit<-modFit(f=ssr,p=c("logGamma"=-12),lower=-16,upper=-8,scenario_num=5)
parmsinit_back<-c(parmsinit[names(parmsinit) != "logGamma"])
for (freq in c(0.25,0.5,1,2,3)) {
#for (freq in 2){ 
for (scenario_num in 1:10) {
    print(scenario_num)
    fit <- optimize(f=ssr, interval=c(-16,-8),
                    scenario_num=scenario_num, freq = freq,
                    parmsinit=parmsinit_back,obs=obs,D2R=D2R)
    print(fit$minimum)
    
    out <- rbind(out, cbind(scenario_num=scenario_num, 
                            samplingfreq=freq,
                            logGamma=fit$minimum))
    if (plotCurves) {
      ssr(logGamma=fit$minimum, scenario_num=scenario_num,
          freq=freq, parmsinit=parmsinit_back,obs=obs,D2R=D2R,
          pdf=paste0(odir,"scenario",scenario_num,"freq",freq,".pdf"))
    }
  }
}
write.table(out, file=paste0(odir,"out_Scenario_freq.txt"),
            sep="\t", quote=FALSE,
            row.names=FALSE, col.names=TRUE)
out   #return
#...................................lineplot
pdf(file=paste0(odir,"scenario1_10_pure",".pdf"), width=7.5, height=5.5)
omar <- par("mar")
out_scenario<-out
scenarionums<-c(1,2,3,4,8)
choosefrom<-c(6,12,13,15,1)
out_scenario<-out[which(out$scenario_num%in%scenarionums),]
out_scenario[,"logGamma"]<-out_scenario[,"logGamma"]- parmsinit[["logGamma"]]
out_scenario_process<-reshape(out_scenario,idvar="samplingfreq",
                              timevar="scenario_num", direction="wide")
par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
plot(out_scenario_process[,"samplingfreq"],out_scenario_process[,"logGamma.1"],
     xlab="Sampling frequency in hours", 
     ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
     pch=choosefrom[1],cex=1.5,type="b",ylim=range(out_scenario[,"logGamma"]))
for(i in 3:ncol(out_scenario_process)){
  lines(out_scenario_process[,"samplingfreq"],out_scenario_process[,i], 
        pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
}
if(leg==TRUE){
names_legends=c("1. None", expression(italic("2. CST")),expression(italic("3. LAG")),expression(italic("4. DNS")),expression(italic("5. MAT")))
legend("bottom",inset = c(-0.45),legend=names_legends,
       title=expression(paste(bold("Functions included in the backward model: "))),
       pch = choosefrom, bty="n", title.adj = 0, horiz=T) }
graphics.off()
##
pdf(file=paste0(odir,"scenario1_10_combination",".pdf"), width=7.5, height=5.5)
omar <- par("mar")
out_scenario<-out
scenarionums<-c(5,6,7,9,10)
choosefrom<-c(11,17,16,8,0)
out_scenario<-out[which(out$scenario_num%in%scenarionums),]
out_scenario[,"logGamma"]<-out_scenario[,"logGamma"]- parmsinit[["logGamma"]]
out_scenario_process<-reshape(out_scenario,idvar="samplingfreq",timevar="scenario_num", 
                              direction="wide")
par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
plot(out_scenario_process[,"samplingfreq"],out_scenario_process[,"logGamma.5"],
     xlab="Sampling frequency in hours", 
     ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
     pch=choosefrom[1],cex=1.5,type="b",ylim=range(out_scenario[,"logGamma"]))
for(i in 3:ncol(out_scenario_process)){
  lines(out_scenario_process[,"samplingfreq"],out_scenario_process[,i], 
        pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
}
if(leg==TRUE){
names_legends=c(expression(italic("6. CST+LAG")),expression(italic("7. CST+DNS")),
                expression(italic("8. CST+LAG+DNS")),expression(italic("9. CST+DNS+MAT")),"10. All")
legend("bottom",inset = c(-0.55),legend=names_legends,
       title=expression(paste(bold("Functions included in the backward model: "))),
       pch = choosefrom, ncol = 2, bty="n", title.adj = 0)} 
graphics.off()
}
