#forward model with cost, lag phase and phase effect to generate data.
#case defination - cost + lagphase + phase effect -> Scenario5
backwardmodel<-function(scenario_num,logGamma,parmsinit,times,D2R)
{
  pros_sub<-scenario(scenario_num)
  if(scenario_num<=7){
    fm <- rodeo$new(vars=rd("vars.txt"), pars=rd("pars.txt"),
                    funs=rd("funs.txt"), pros=rd("pros_mat_all.txt")[pros_sub,],
                    stoi=as.matrix(rd("stoi.txt", row.names=1)), asMatrix=TRUE, dim=c(1))
  }else{
    fm <- rodeo$new(vars=rd("vars_young.txt"), pars=rd("pars.txt"),
                    funs=rd("funs.txt"), pros=rd("pros_mat_all.txt")[pros_sub,],
                    stoi=as.matrix(rd("stoi_young.txt", row.names=1)), asMatrix=TRUE, dim=c(1))}
  fm$compile(sources=paste0(dir,"/functions.f95"))
  #initalize state variables
  tmp <- D2R[fm$namesVars()] 
  fm$setVars(tmp)
  #initialize parameters
  tmp<-c(parmsinit, logGamma=logGamma)[fm$namesPars()]
  fm$setPars(tmp)
    
  #---------------------------------------------------------------------------------------------------
  #Normal dynamic solution
  out<-fm$dynamics(times=times)
  
  return(out)
}