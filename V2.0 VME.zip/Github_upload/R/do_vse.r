rm(list=ls())
#options(warn=1)
setwd('/your/folder/path/R')
odir <- "../out/"
dir<-"../Rodeo"
plotCurves<-TRUE        #plots prediction curves for each local sensitivity test
plotCurves_mu<-FALSE    #mu<-  growth rate constant
plotCurves_lg<-FALSE    #log <-logGamma (plasmid transfer rate constant)
plotCurves_lp<-FALSE    #lp <- lag phase 
plotCurves_mt<-FALSE    #mt<- maturation time
plotCurves_cost<-FALSE  #cost <- plasmid bearing costs
plotCurves_D2R<-FALSE   #D2R<- D:R ratio
#combinations <- "../in/combination.txt"
# packages
library("deSolve")
library("rodeo")
library("lhs")
library("plyr")
library("reshape2")
library("FME")
# load utility functions
sources <- list.files(path=".", pattern="^func_.+[.]r$", full.names=TRUE)
for (src in sources) {
  source(src)
  print(paste0("loaded '",src,"'"))
}
#.......Basic declarations and data generator
rd <- function(f, ...) {
  read.table(paste0(dir,"/",f), header=TRUE, sep="\t", ...)
}
parmsinit<-c(mu=1.7,cost=0.3,kc=1e10,logGamma=-12,lp = 1.5,mt=1)
D2R<-c(D=1e4, R=1e4, T=0, T_young=0, T_mature=0)

#.......Forward model
obs<-forwardmodel(scenario_num=10,parmsinit=parmsinit,D2R=D2R)   #generates virtual observations for default conditions

#Scenario 1-10 (Scenarios Vs Sampling frequencies)
out_scenario<-scenario1_10(parmsinit=parmsinit, D2R=D2R,obs=obs,leg=TRUE)
            
#Sensitivity analysis
# leg when TRUE produces final figures with legends. (important for the manuscript/presentations 
#to not have legends in every plot)

#case 1- Changed mu 
out_mu<-scenario_mu(D2R=D2R,leg=FALSE)

#case 2- Changed logGamma
out_lg<-scenario_lg(D2R=D2R,leg=FALSE)

#case 3 - Changed lagPhase length 
out_lp<-scenario_lp(D2R=D2R,leg=FALSE)

#case 4: changed mu, fixed numbers of samples taken per doubling time
out_mu_samples<-scenario_mu_samples(forwardsampling=4, backwardsampling=2)

#case 5: changed mt (maturation time for T) #sensitivity w.r.t. mt was tested at logGamma -9 to amplify the effect
parmsinit<-c(mu=1.7,cost=0.3,kc=1e10,logGamma=-9,lp = 1.5,mt=1)
out_mt<-scenario_mt(parmsinit=parmsinit,D2R=D2R,leg=FALSE)

#case 6: changed plasmid bearing cost
out_cost<-scenario_cost(D2R=D2R,leg=TRUE)

#case 7: changed D2R ratio
parmsinit<-c(mu=1.7,cost=0.3,kc=1e10,logGamma=-12,lp = 1.5,mt=1)
out_D2R<-scenario_D2R(parmsinit=parmsinit,D2R=D2R,leg=TRUE)
                  

