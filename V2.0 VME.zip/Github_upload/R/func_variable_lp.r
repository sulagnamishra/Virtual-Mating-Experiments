scenario_lp<-function(D2R,leg)
{
  #case 3- Changed logphase length
  testfreq<-2
  out_lp<-NULL
  i<-0
  for (lp in c(0,.2,.5,1,1.5,2)) {
    i<-i+1
    parmsinit_lp<-c(parmsinit[names(parmsinit) != "lp"], lp=lp)
    parmsinit_back<-c(parmsinit_lp[names(parmsinit_lp) != "logGamma"])
    obs<-forwardmodel(scenario_num=10, parmsinit = parmsinit_lp,D2R=D2R)
    for (scenario_num in 1:10) {
      fit_lp <- optimize(f=ssr, interval=c(-16,-8),
                         scenario_num=scenario_num, freq = testfreq,parmsinit=parmsinit_back,
                         obs=obs,D2R=D2R)
      out_lp <- rbind(out_lp, cbind(scenario_num=scenario_num, lp=lp,freq=testfreq,
                                    logGamma=fit_lp$minimum))
      if (plotCurves_lp) {
        ssr(logGamma=fit_lp$minimum, scenario_num=scenario_num,
            freq= testfreq,parmsinit = parmsinit_back, obs = obs,D2R=D2R,
            pdf=paste0(odir,"scenario",scenario_num,"lp",lp,"freq",testfreq,".pdf"))
      }
    }
  }
  write.table(out_lp, file=paste0(odir,"out_lp_scenario.txt"), sep="\t", quote=FALSE,
              row.names=FALSE, col.names=TRUE)
  out_lp #return

  #.......................Plots...............................
  pdf(file=paste0(odir,"lp_pure",".pdf"), width=7.5, height=5.5)
  scenarionums<-c(1,2,3,4,8)
  choosefrom<-c(6,12,13,15,1)
  out_lp_process<-out_lp[which(out_lp$scenario_num%in%scenarionums),]
  out_lp_process[,"logGamma"]<-out_lp_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_lp_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_lp_process<-reshape(subset(as.data.frame(out_lp_process),select= -freq),idvar="lp",
                          timevar="scenario_num", direction="wide")
  plot(out_lp_process[,"lp"],out_lp_process[,"logGamma.1"],xlab="Lag Phase in hours", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  for(i in 3:ncol(out_lp_process)){
    lines(out_lp_process[,"lp"],out_lp_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c("1. None", expression(italic("2. CST")),expression(italic("3. LAG")),expression(italic("4. DNS")),expression(italic("5. MAT")))
    legend("bottom",inset = c(-0.45),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, bty="n", title.adj = 0, horiz=T)} 
  graphics.off()
  
  #.....................Combination plots.............................
  pdf(file=paste0(odir,"lp_combination",".pdf"), width=7.5, height=5.5)
  scenarionums<-c(5,6,7,9,10)   #Scenario nums based on the sequence in the code.
  choosefrom<-c(11,17,16,8,0)
  out_lp_process<-out_lp[which(out_lp$scenario_num%in%scenarionums),]
  out_lp_process[,"logGamma"]<-out_lp_process[,"logGamma"]- parmsinit[["logGamma"]]
  ylim<-range(out_lp_process[,"logGamma"])
  par(mar=c(9,6,1,4),xpd=TRUE) #bottom legend
  out_lp_process<-reshape(subset(as.data.frame(out_lp_process),select= -freq),idvar="lp",
                          timevar="scenario_num", direction="wide")
  plot(out_lp_process[,"lp"],out_lp_process[,"logGamma.5"],xlab="Lag Phase in hours", 
       ylab=expression(paste("Error in predicted ",gamma," in log10 units")),
       pch=choosefrom[1],cex=1.5,type="b",ylim=ylim)
  for(i in 3:ncol(out_lp_process)){
    lines(out_lp_process[,"lp"],out_lp_process[,i], pch = choosefrom[i-1],cex=1.5+0.1*i,type="b")
  }
  if(leg==TRUE){
    names_legends=c(expression(italic("6. CST+LAG")),expression(italic("7. CST+DNS")),
                    expression(italic("8. CST+LAG+DNS")),expression(italic("9. CST+DNS+MAT")),"10. All")
    legend("bottom",inset = c(-0.55),legend=names_legends,
           title=expression(paste(bold("Functions included in the backward model: "))),
           pch = choosefrom, ncol = 2, bty="n", title.adj = 0)}
  graphics.off()
}