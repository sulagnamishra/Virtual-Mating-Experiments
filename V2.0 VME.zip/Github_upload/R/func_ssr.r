# objective function used to estimate parameter gamma
ssr <- function(logGamma,scenario_num,freq,parmsinit,obs,D2R,pdf=NULL,forwardsampling=NULL,backwardsampling=NULL) {
  obs_subset<-obs[which(obs[,"time"]%%freq==0),]
  obs_subset<-cbind(obs_subset,T=obs_subset[,"T_young"]+obs_subset[,"T_mature"])
  #colnames(obs_subset)<-c(colnames(obs_subset[,-ncol(obs_subset)]),"T")
  y<-c("time","D","R","T")
  obs_subset<-obs_subset[,y]
  times=obs_subset[,"time"]
  if(!is.null(forwardsampling))
  {
    ratio<-round(forwardsampling/backwardsampling,2)
    rownumbers<-seq(1,nrow(obs),by=ratio)
    obs_subset<-obs[rownumbers,] 
    times<-obs_subset[,"time"]
    }
  
  sim<-backwardmodel(scenario_num = scenario_num, 
                     logGamma=logGamma,parmsinit=parmsinit,times=times, D2R = D2R) #logGamma to be predicted

  #print(sim)
  #---------------------------------------------------------------------------------------------------
  if(scenario_num>7){
    sim<-cbind(sim,T=sim[,"T_young"]+sim[,"T_mature"])
    sim<-sim[,y]
  }else {sim<-sim[,y]}
  
  if(!is.null(pdf))
  {
    pdf(file=pdf, width=8, height=8)
    omar <- par("mar")
    #par(mar=c(4.2, 4.2, 0.2, 0.2))
    y1<-c("D","R","T")
    #times=seq(from = 0, to = 12, by = freq)
    yrange= c(5, max(rbind(obs_subset,sim)[,y1]))
    plot(range(times), yrange, type="n", ann=FALSE,
         log="y",xlab="Density of the strains in CFU/ml",ylab="Time in hours")
    clr <- c(D="red", R="blue", T="magenta")
    for (v in names(clr)) {
      points(obs_subset[,c("time",v)], pch=20, col=clr[v])
      lines(sim[,c("time",v)], pch=20, col=clr[v])
    }
    title(main=paste0("Scenario:",scenario_num))
    legend("bottomright", bty="n", legend=substitute(
      paste("log",{}[10],gamma,"=",lg), list(lg=signif(logGamma,3))))
    par(mar=omar)
    graphics.off()
  }
  i <- 2:nrow(sim)
  out <- sum((log10(obs_subset[i,c("D","R","T")]) - log10(sim[i,c("D","R","T")]))^2)
  if (!is.finite(out)) {
    print("obs")
    print(obs_subset[i,c("D","R","T")])
    print("sim")
    print(sim[i,c("D","R","T")])
    stop("non-finite sum of squared residuals") 
  }
  out
}